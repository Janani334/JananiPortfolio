const repo = 'https://github.com/Janani334/JananiMurugan'
const tree = (p: string) => `${repo}/tree/main/${p}`
const blob = (p: string) => `${repo}/blob/main/${p}`

export const profile = {
  name: 'Janani Murugan',
  initials: 'JM',
  role: 'Aspiring Data Analyst | Excel · SQL · Power BI | Python & GenAI Learner',
  email: 'jananim373@gmail.com',
  phone: '+91 90421 25373',
  location: 'Tamil Nadu, India',
  photo: '/img/janani-portrait.jpg',
  resume: '/files/Janani_Murugan_Resume.pdf',
  github: 'https://github.com/Janani334',
  repo,
  linkedin: 'https://www.linkedin.com/in/m--janani',
  quote: '"Turning raw data into clear stories that drive better decisions."',
}

export const navItems: [string, string][] = [
  ['home', 'Home'],
  ['about', 'About'],
  ['skills', 'Skills'],
  ['projects', 'Projects'],
  ['education', 'Education'],
  ['certifications', 'Certifications'],
  ['journey', 'Journey'],
  ['contact', 'Contact'],
]

export const aboutParagraphs = [
  'I am an M.Sc. Computer Science postgraduate with 90.44% and a 6th University Rank Holder at Bharathiar University through my affiliated college, Pioneer College of Arts and Science. I am passionate about technology, data, and continuous learning, with a strong interest in data-driven problem-solving and business insights.',
  'Currently, I am working as a Data Analytics Trainee at Anudip Foundation, where I have completed six practical projects across Microsoft Excel, SQL, and Power BI, gaining hands-on experience in data cleaning, analysis, visualization, dashboard development, KPI analysis, and deriving meaningful business insights.',
  'Along with my technical skills, I bring strong communication, presentation, public speaking, problem-solving, teamwork, and time-management skills, sharpened through event hosting and anchoring.',
  'I am currently seeking opportunities as a Junior Data Analyst or Reporting Analyst, where I can apply my skills, contribute to data-driven solutions, and grow professionally.',
]

export const aboutChips: [string, string][] = [
  ['M.Sc. CS', '90.44% · 2026'],
  ['6th Rank', 'Bharathiar University'],
  ['Trainee', 'Data Analytics, Anudip Foundation'],
  ['6 Projects', 'Excel · SQL · Power BI'],
  ['Insights', 'KPIs, dashboards & reporting'],
  ['Speaker', 'Event hosting & anchoring'],
]

export const skillGroups: { title: string; items: [string, string][] }[] = [
  {
    title: 'Data Analysis',
    items: [
      ['Microsoft Excel', 'Pivot Tables, SUMIFS, INDEX/MATCH, VLOOKUP and slicer-driven dashboards.'],
      ['Data Cleaning', 'Profiling, fixing blanks, duplicates and inconsistent categories before analysis.'],
      ['KPI Analysis', 'Defining revenue, margin, defect-rate and target-achievement KPIs.'],
    ],
  },
  {
    title: 'Database',
    items: [
      ['SQL', 'Joins, subqueries, aggregations and conditional logic for business questions.'],
      ['MySQL', 'Designing relational schemas with primary and foreign keys.'],
      ['ERD Design', 'Modelling entities and relationships before writing a single query.'],
    ],
  },
  {
    title: 'Business Intelligence',
    items: [
      ['Power BI', 'Interactive reports with filters, drill-through and KPI cards.'],
      ['Power Query', 'Consolidating and transforming operational data for reporting.'],
      ['Data Visualization', 'Choosing the right chart so the insight is obvious at a glance.'],
      ['Dashboard Development', 'End-to-end dashboards from raw data to executive summary.'],
    ],
  },
  {
    title: 'Programming',
    items: [
      ['Python', 'Pandas, NumPy, Matplotlib and Seaborn for analysis and charts.'],
      ['Generative AI', 'Using AI tools to speed up analysis, documentation and learning.'],
      ['Visual Basic', 'Foundational programming and simple automation.'],
    ],
  },
  {
    title: 'Productivity',
    items: [
      ['MS Word', 'Clear documentation and project reports.'],
      ['MS PowerPoint', 'Presenting findings and recommendations to stakeholders.'],
      ['Fast Typing', 'Fast and accurate typing, First Class with Distinction (TME English).'],
    ],
  },
  {
    title: 'Soft Skills',
    items: [
      ['Communication', 'Explaining data findings in simple, business-friendly language.'],
      ['Public Speaking', 'Confident presenter and event host / anchor.'],
      ['Problem Solving', 'Breaking business questions into measurable analysis steps.'],
      ['Teamwork', 'Collaborating on shared projects and deadlines.'],
      ['Time Management', 'Delivering six training projects on schedule.'],
    ],
  },
]

export type Shot = [string, string]

export type Project = {
  id: string
  tool: 'Excel' | 'SQL' | 'Power BI'
  title: string
  summary: string
  features: string[]
  tags: string[]
  shots: Shot[]
  github: string
  readme: string
  video?: string
}

export const projects: Project[] = [
  {
    id: 'freshmart',
    tool: 'Excel',
    title: 'FreshMart Sales Dashboard',
    summary:
      'Business performance analysis of 2,500+ retail transactions across regions, store types, membership tiers and sales channels.',
    features: ['Data profiling & cleaning', 'SUMIFS · INDEX/MATCH · VLOOKUP', 'Pivot Tables', 'Slicer dashboard', 'Revenue & profit trends'],
    tags: ['Microsoft Excel', 'Pivot Tables', 'KPI Analysis'],
    shots: [
      ['/img/projects/freshmart-final.png', 'FreshMart final dashboard'],
      ['/img/projects/freshmart-dashboard.png', 'FreshMart dashboard build'],
    ],
    github: tree('Excel/Projects/FreshMart'),
    readme: blob('Excel/Projects/FreshMart/FM_README_md/README.md'),
    video: '/videos/freshmart.mp4',
  },
  {
    id: 'trendkart',
    tool: 'Excel',
    title: 'TrendKart Fashion Enterprise Analytics',
    summary:
      'Retail analytics on 3,000 sales transactions covering brands, stores vs targets, payment methods, returns and high-value customers.',
    features: ['23 data-quality issues logged', 'Store target tracking', 'Returns impact', 'Customer value analysis'],
    tags: ['Microsoft Excel', 'Data Cleaning', 'Dashboard'],
    shots: [
      ['/img/projects/trendkart-final.png', 'TrendKart final dashboard'],
      ['/img/projects/trendkart-dashboard.png', 'TrendKart dashboard build'],
    ],
    github: tree('Excel/Projects/TrendKart'),
    readme: blob('Excel/Projects/TrendKart/TK_README.md/README.md'),
    video: '/videos/trendkart.mp4',
  },
  {
    id: 'healthplus',
    tool: 'SQL',
    title: 'HealthPlus Care Database Analytics',
    summary:
      'Relational healthcare database covering 18 clinics and 220+ specialists, analysed to compare provider fees and regional cost distribution.',
    features: ['ERD & schema design', 'PK / FK relationships', 'Joins & subqueries', 'Fee-pricing insights'],
    tags: ['SQL', 'MySQL', 'ERD'],
    shots: [
      ['/img/projects/healthplus-erd.png', 'HealthPlus Care ER diagram'],
      ['/img/projects/healthplus-schema.png', 'Database schema'],
      ['/img/projects/healthplus-profiling.png', 'Data profiling queries'],
      ['/img/projects/healthplus-cleaning.png', 'Data cleaning queries'],
      ['/img/projects/healthplus-analysis-1.png', 'Data analysis queries (1)'],
      ['/img/projects/healthplus-analysis-2.png', 'Data analysis queries (2)'],
    ],
    github: tree('SQL/Projects/Healthplus_care_DB'),
    readme: blob('SQL/Projects/Healthplus_care_DB/HealthcareREADME/README.md'),
  },
  {
    id: 'medicare',
    tool: 'SQL',
    title: 'Medicare Hospital Analytics DB',
    summary:
      'Hospital analytics database linking hospitals, departments, doctors, patients, appointments, billing, lab and pharmacy data.',
    features: ['12-table relational model', 'Capacity & specialisation analysis', 'Consultation fee comparison', 'Data-quality checks'],
    tags: ['SQL', 'MySQL', 'ERD'],
    shots: [
      ['/img/projects/medicare-erd.png', 'Medicare ER diagram'],
      ['/img/projects/medicare-schema.png', 'Database schema'],
      ['/img/projects/medicare-profiling.png', 'Data profiling queries'],
      ['/img/projects/medicare-cleaning.png', 'Data cleaning queries'],
      ['/img/projects/medicare-analysis.png', 'Data analysis queries'],
    ],
    github: tree('SQL/Projects/Medicare'),
    readme: blob('SQL/Projects/Medicare/MediREADME.md/README.md'),
  },
  {
    id: 'aerohome',
    tool: 'Power BI',
    title: 'AeroHome Manufacturing Dashboard',
    summary:
      'Performance & operations dashboard tracking planned vs actual production, shortfalls, defect rates, downtime reasons and procurement spend.',
    features: ['Star-schema data model', 'Power Query prep', 'Downtime root causes', 'Procurement KPIs'],
    tags: ['Power BI', 'Power Query', 'Data Modelling'],
    shots: [
      ['/img/projects/aerohome-final.png', 'AeroHome final dashboard'],
      ['/img/projects/aerohome-dashboard.png', 'AeroHome dashboard build'],
    ],
    github: tree('Power%20BI/Projects/AeroHome_Manufacturing'),
    readme: blob('Power%20BI/Projects/AeroHome_Manufacturing/AeroHome_README/README.md'),
    video: '/videos/aerohome.mp4',
  },
  {
    id: 'novatech',
    tool: 'Power BI',
    title: 'NovaTech Manufacturing Performance',
    summary:
      'Manufacturing analysis across plants, products and suppliers covering production, defects, downtime, unit cost and energy consumption.',
    features: ['Plant comparison', 'Supplier PO distribution', 'Energy consumption', 'Executive KPI cards'],
    tags: ['Power BI', 'Data Modelling', 'KPI Analysis'],
    shots: [
      ['/img/projects/novatech-final.png', 'NovaTech final dashboard'],
      ['/img/projects/novatech-dashboard.png', 'NovaTech dashboard build'],
    ],
    github: tree('Power%20BI/Projects/Nova_Manufacturing'),
    readme: blob('Power%20BI/Projects/Nova_Manufacturing/Nova_README/README.md'),
    video: '/videos/novatech.mp4',
  },
]

export const education = [
  {
    title: 'M.Sc. Computer Science',
    place: 'Pioneer College of Arts and Science, Jothipuram (Bharathiar University)',
    when: '2026',
    score: '90.44% · 6th University Rank',
  },
  { title: 'B.Sc. Computer Science', place: 'Pioneer College of Arts and Science, Jothipuram', when: '2024', score: '89.77%' },
  { title: 'HSC', place: 'Pioneer Mills Higher Secondary School, Jothipuram', when: '2021', score: '92.04%' },
  {
    title: 'SSLC',
    place: 'Swami Shivananda Higher Secondary School, Periyanaicken Palayam',
    when: '2019',
    score: '92.20% · 2nd Rank',
  },
]

export const certs: { type: 'Achievement' | 'Certification'; title: string; detail: string }[] = [
  { type: 'Achievement', title: '6th University Rank Holder', detail: 'M.Sc. Computer Science · Bharathiar University · 2026' },
  { type: 'Achievement', title: 'Proficiency Award', detail: 'Highest score in M.Sc. Computer Science · 2026' },
  { type: 'Achievement', title: '1st Prize – State-Level Essay Writing', detail: 'English essay competition on Gurupuja · 2026' },
  { type: 'Achievement', title: 'First Class with Distinction', detail: 'TME English Typewriting · 2026' },
  { type: 'Achievement', title: 'Proficiency Award', detail: 'Highest score in B.Sc. Computer Science · 2023' },
  { type: 'Achievement', title: '2nd Rank – SSLC', detail: 'SSLC Public Examination · 2019' },
  { type: 'Certification', title: 'SQL Certification', detail: 'Relational databases and querying' },
  { type: 'Certification', title: 'MS Office Certification', detail: 'Word, Excel and PowerPoint' },
  { type: 'Certification', title: 'UI/UX for Beginners', detail: 'Design fundamentals and usability' },
  { type: 'Certification', title: 'Online Typewriting Course', detail: 'Fast and accurate typing' },
]

export const journey: [string, string][] = [
  ['2019', 'SSLC with 92.20% and 2nd Rank in the public examination.'],
  ['2021', 'HSC completed with 92.04% at Pioneer Mills Higher Secondary School.'],
  ['2023', 'Proficiency Award for the highest score in B.Sc. Computer Science.'],
  ['2024', 'Graduated B.Sc. Computer Science with 89.77%.'],
  ['2026', 'M.Sc. Computer Science with 90.44%, 6th University Rank at Bharathiar University.'],
  ['Trainee', 'Data Analytics Trainee at Anudip Foundation, completing six Excel, SQL and Power BI projects.'],
  ['Next', 'Seeking a Junior Data Analyst / Reporting Analyst role to turn data into business decisions.'],
]
