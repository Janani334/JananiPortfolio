'use client'

import { useState } from 'react'
import { profile } from '@/lib/portfolio-data'
import { DownloadIcon, GithubIcon, LinkedinIcon, MailIcon, PhoneIcon, external } from './icons'
import { ResumeButton } from './resume-viewer'

type Fields = { name: string; email: string; subject: string; message: string }
type Errors = Partial<Record<keyof Fields, string>>

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/
const empty: Fields = { name: '', email: '', subject: '', message: '' }

function validate(f: Fields): Errors {
  const e: Errors = {}
  if (!f.name.trim()) e.name = 'Please enter your name.'
  if (!f.email.trim()) e.email = 'Please enter your email.'
  else if (!emailPattern.test(f.email.trim())) e.email = 'Please enter a valid email address.'
  if (!f.message.trim()) e.message = 'Please write a message.'
  else if (f.message.trim().length < 10) e.message = 'Message should be at least 10 characters.'
  return e
}

export function Contact() {
  const [fields, setFields] = useState<Fields>(empty)
  const [errors, setErrors] = useState<Errors>({})
  const [status, setStatus] = useState<{ type: 'idle' | 'ok' | 'error' | 'sending'; msg: string }>({ type: 'idle', msg: '' })

  const onChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const name = e.target.name as keyof Fields
    const next = { ...fields, [name]: e.target.value }
    setFields(next)
    if (errors[name]) setErrors(validate(next))
  }

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const errs = validate(fields)
    setErrors(errs)
    if (Object.keys(errs).length) {
      setStatus({ type: 'error', msg: '> please fix the highlighted fields' })
      return
    }
    const subject = fields.subject.trim() || `Portfolio message from ${fields.name.trim()}`
    const body = `${fields.message.trim()}\n\n— ${fields.name.trim()} (${fields.email.trim()})`
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    setFields(empty)
    setStatus({ type: 'ok', msg: '> message sent. Thank you, I will get back to you soon!' })
  }

  const bind = (name: keyof Fields) => ({
    name,
    value: fields[name],
    onChange,
    'aria-invalid': !!errors[name],
    'aria-describedby': errors[name] ? `${name}-err` : undefined,
  })

  return (
    <section id="contact">
      <h2 className="title">Contact</h2>
      <div className="contact-grid">
        <form className="card glass portal" name="contact" onSubmit={onSubmit} noValidate>
          <p className="mono tag">{'> open a channel'}</p>
          <label>
            Name *
            <input {...bind('name')} autoComplete="name" />
            {errors.name && (
              <em id="name-err" className="err">
                {errors.name}
              </em>
            )}
          </label>
          <label>
            Email *
            <input {...bind('email')} type="email" autoComplete="email" />
            {errors.email && (
              <em id="email-err" className="err">
                {errors.email}
              </em>
            )}
          </label>
          <label>
            Subject
            <input {...bind('subject')} placeholder="Job opportunity, collaboration…" />
          </label>
          <label>
            Message *
            <textarea {...bind('message')} rows={5} />
            {errors.message && (
              <em id="message-err" className="err">
                {errors.message}
              </em>
            )}
          </label>
          <button className="btn primary" type="submit" disabled={status.type === 'sending'}>
            {status.type === 'sending' ? 'Sending…' : 'Send Message'}
          </button>
          <p className={`mono small status ${status.type}`} role="status" aria-live="polite">
            {status.msg}
          </p>
        </form>
        <div className="card glass links">
          <h3>{"Let's connect"}</h3>
          <p>Open to Junior Data Analyst, Reporting Analyst and BI Analyst opportunities.</p>
          <a href={`mailto:${profile.email}`}>
            <MailIcon /> {profile.email}
          </a>
          <a href={`tel:${profile.phone.replace(/\s/g, '')}`}>
            <PhoneIcon /> {profile.phone}
          </a>
          <a href={profile.linkedin} {...external}>
            <LinkedinIcon /> linkedin.com/in/m--janani
          </a>
          <a href={profile.github} {...external}>
            <GithubIcon /> github.com/Janani334
          </a>
          <ResumeButton className="link-btn" />
          <a href={profile.resume} download="Janani_Murugan_Resume.pdf">
            <DownloadIcon /> Download Resume (PDF)
          </a>
        </div>
      </div>
    </section>
  )
}
