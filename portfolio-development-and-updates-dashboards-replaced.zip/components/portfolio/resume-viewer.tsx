'use client'

import { useCallback, useEffect, useState } from 'react'
import { profile } from '@/lib/portfolio-data'
import { DownloadIcon, EyeIcon, external } from './icons'
import { Modal } from './modal'

const OPEN_EVENT = 'resume:open'
const fileName = 'Janani_Murugan_Resume.pdf'

export function ResumeButton({ className = 'btn', children }: { className?: string; children?: React.ReactNode }) {
  return (
    <button type="button" className={className} onClick={() => dispatchEvent(new Event(OPEN_EVENT))} aria-haspopup="dialog">
      {children ?? (
        <>
          <EyeIcon /> View Resume
        </>
      )}
    </button>
  )
}

export function ResumeViewer() {
  const [open, setOpen] = useState(false)
  const [inlinePdf, setInlinePdf] = useState(true)
  const close = useCallback(() => setOpen(false), [])

  useEffect(() => {
    setInlinePdf(navigator.pdfViewerEnabled !== false)
    const onOpen = () => setOpen(true)
    addEventListener(OPEN_EVENT, onOpen)
    return () => removeEventListener(OPEN_EVENT, onOpen)
  }, [])

  if (!open) return null

  return (
    <Modal label={`${profile.name} resume`} onClose={close} className="resume-modal">
      <div className="resume-box glass">
        <div className="resume-bar">
          <p className="mono small">{fileName}</p>
          <div className="resume-actions">
            <a className="btn" href={profile.resume} {...external}>
              Open in new tab
            </a>
            <a className="btn primary" href={profile.resume} download={fileName}>
              <DownloadIcon /> Download
            </a>
          </div>
        </div>
        {inlinePdf ? (
          <iframe className="resume-frame" src={`${profile.resume}#view=FitH`} title={`${profile.name} resume (PDF)`} />
        ) : (
          <div className="resume-fallback">
            <p>{"Your browser can't preview PDFs inline."}</p>
            <p className="mono small">{'> use "Open in new tab" or "Download" above'}</p>
          </div>
        )}
      </div>
    </Modal>
  )
}
