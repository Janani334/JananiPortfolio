'use client'

import { useEffect, useRef } from 'react'

export function Modal({
  label,
  onClose,
  className = '',
  children,
}: {
  label: string
  onClose: () => void
  className?: string
  children: React.ReactNode
}) {
  const closeRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    return () => {
      removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
      previous?.focus()
    }
  }, [onClose])

  return (
    <div
      className={`lightbox ${className}`}
      role="dialog"
      aria-modal="true"
      aria-label={label}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <button type="button" ref={closeRef} className="lb-close" onClick={onClose} aria-label="Close">
        {'×'}
      </button>
      {children}
    </div>
  )
}
