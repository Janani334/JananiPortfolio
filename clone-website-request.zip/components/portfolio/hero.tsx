'use client'

import { useEffect, useRef, useState } from 'react'
import { profile } from '@/lib/portfolio-data'
import { DownloadIcon, Socials } from './icons'

export function Hero() {
  const wrapRef = useRef<HTMLDivElement>(null)
  const [showPhoto, setShowPhoto] = useState(true)

  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches || !matchMedia('(hover: hover)').matches) return
    const onMove = (e: MouseEvent) => {
      if (!wrapRef.current) return
      const x = e.clientX / innerWidth - 0.5
      const y = e.clientY / innerHeight - 0.5
      wrapRef.current.style.transform = `translate(${x * 18}px,${y * 18}px)`
    }
    addEventListener('mousemove', onMove)
    return () => removeEventListener('mousemove', onMove)
  }, [])

  return (
    <section id="home" className="hero">
      <div className="hero-text">
        <p className="mono tag">WELCOME TO MY WEBSITE</p>
        <h1>
          {"I'm "}
          <span className="gold">{profile.name}</span>
        </h1>
        <h2>{profile.role}</h2>
        <p className="lead">
          M.Sc. Computer Science postgraduate with <b>90.44%</b> and a <b>6th University Rank Holder</b> at Bharathiar
          University. I enjoy exploring data, spotting patterns and turning raw information into{' '}
          <b>meaningful business insights</b>.
        </p>
        <p className="lead">
          Data Analytics Trainee at <b>Anudip Foundation</b> with six hands-on projects in{' '}
          <b>Microsoft Excel, SQL and Power BI</b>, including FreshMart Sales, HealthPlus Care Database and AeroHome
          Manufacturing.
        </p>
        <p className="mono small">Currently seeking: Junior Data Analyst · Reporting Analyst · BI Analyst roles</p>
        <p className="quote">{profile.quote}</p>
        <div className="btns">
          <a className="btn primary" href="#about">
            Explore My Universe
          </a>
          <a className="btn" href="#projects">
            View Projects
          </a>
          <a className="btn ghost" href="#contact">
            Contact Me
          </a>
          <a className="btn ghost" href={profile.resume} download="Janani_Murugan_Resume.pdf">
            <DownloadIcon /> Download Resume
          </a>
        </div>
        <Socials />
      </div>
      <div className="portrait-wrap" ref={wrapRef}>
        <div className="ring r1">
          <i />
        </div>
        <div className="ring r2">
          <i />
        </div>
        <div className="portrait">
          {showPhoto && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={profile.photo || '/placeholder.svg'}
              alt={`Portrait of ${profile.name}`}
              fetchPriority="high"
              onError={() => setShowPhoto(false)}
            />
          )}
          <span className="initials">{profile.initials}</span>
        </div>
      </div>
    </section>
  )
}
