'use client'

import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { navItems, profile } from '@/lib/portfolio-data'

export function SiteNav() {
  const [open, setOpen] = useState(false)
  const [solid, setSolid] = useState(false)
  const [active, setActive] = useState('home')
  const navRef = useRef<HTMLElement>(null)
  const dotRef = useRef<HTMLSpanElement>(null)

  useEffect(() => {
    const onScroll = () => setSolid(window.scrollY > 40)
    onScroll()
    addEventListener('scroll', onScroll, { passive: true })
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: '-45% 0px -50% 0px' },
    )
    navItems.forEach(([id]) => {
      const el = document.getElementById(id)
      if (el) io.observe(el)
    })
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    addEventListener('keydown', onKey)
    return () => {
      removeEventListener('scroll', onScroll)
      removeEventListener('keydown', onKey)
      io.disconnect()
    }
  }, [])

  useLayoutEffect(() => {
    const place = () => {
      const link = navRef.current?.querySelector<HTMLAnchorElement>(`a[href="#${active}"]`)
      if (link && dotRef.current) {
        dotRef.current.style.transform = `translateX(${link.offsetLeft + link.offsetWidth / 2 - 4}px)`
      }
    }
    place()
    addEventListener('resize', place)
    return () => removeEventListener('resize', place)
  }, [active])

  const go = (e: React.MouseEvent, id: string) => {
    const el = document.getElementById(id)
    if (!el) return
    e.preventDefault()
    setOpen(false)
    if (id === 'home') window.scrollTo({ top: 0, behavior: 'smooth' })
    else el.scrollIntoView({ behavior: 'smooth', block: 'start' })
    history.pushState(null, '', `#${id}`)
    setActive(id)
  }

  return (
    <header className={`nav${solid || open ? ' solid' : ''}`}>
      <a href="#home" className="brand" onClick={(e) => go(e, 'home')} aria-label={`${profile.name}, back to top`}>
        {'<'}
        {profile.initials}
        {'/>'}
      </a>
      <button
        type="button"
        className="burger"
        aria-label={open ? 'Close menu' : 'Open menu'}
        aria-expanded={open}
        aria-controls="menu"
        onClick={() => setOpen((o) => !o)}
      >
        {open ? '✕' : '☰'}
      </button>
      <nav id="menu" ref={navRef} className={open ? 'open' : ''} aria-label="Sections">
        {navItems.map(([id, label]) => (
          <a
            key={id}
            href={`#${id}`}
            className={active === id ? 'active' : ''}
            aria-current={active === id ? 'true' : undefined}
            onClick={(e) => go(e, id)}
          >
            {label}
          </a>
        ))}
        <span className="dot" ref={dotRef} aria-hidden="true" />
      </nav>
    </header>
  )
}
