import { education } from '@/lib/portfolio-data'

export function Education() {
  return (
    <section id="education">
      <h2 className="title">Education</h2>
      <div className="timeline">
        {education.map((e) => (
          <div className="tl-item card glass" key={e.title}>
            <p className="mono tag">{e.when}</p>
            <h3>{e.title}</h3>
            <p>{e.place}</p>
            <p className="gold mono small">{e.score}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
