'use client'

import { profile } from '@/lib/portfolio-data'
import { Socials } from './icons'

export function SiteFooter() {
  return (
    <footer>
      <strong className="gold">{profile.name}</strong>
      <span>
        Aspiring Data Analyst · Excel · SQL · Power BI <span className="twinkle">{'✦'}</span>
      </span>
      <Socials className="socials center-row" />
      <p className="small">
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault()
            window.scrollTo({ top: 0, behavior: 'smooth' })
            history.pushState(null, '', '#home')
          }}
        >
          {'Back to top ↑'}
        </a>
      </p>
      <p className="small">
        {'© '}
        {new Date().getFullYear()} {profile.name}
      </p>
    </footer>
  )
}
