'use client'

import { useEffect, useRef } from 'react'

const INTERACTIVE =
  'a,button,input,textarea,label,select,p,h1,h2,h3,h4,li,span,b,small,img,figure,.card,.chip,.glass,.nav,.hero-text,.portrait-wrap,.zoom-ctl,.lightbox'

type Star = { x: number; y: number; d: number; r: number; c: string; t: number; fine: boolean }
type Meteor = { x: number; y: number; l: number }

export function SpaceBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const nebulaRef = useRef<HTMLDivElement>(null)
  const moonRef = useRef<HTMLDivElement>(null)
  const glowRef = useRef<HTMLDivElement>(null)
  const view = useRef({ zoom: 1, pan: { x: 0, y: 0 } })

  useEffect(() => {
    const canvas = canvasRef.current!
    const ctx = canvas.getContext('2d')!
    const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches
    const finePointer = matchMedia('(hover: hover) and (pointer: fine)').matches
    const v = view.current
    let w = 0
    let h = 0
    let stars: Star[] = []
    let meteors: Meteor[] = []
    let raf = 0
    const m = { x: 0, y: 0, px: 0, py: 0, cx: -999, cy: -999, gx: -999, gy: -999 }
    let panning = false
    let last = { x: 0, y: 0 }

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      w = innerWidth
      h = innerHeight
      canvas.width = w * dpr
      canvas.height = h * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      const count = Math.round(Math.min((w * h) / 600, w < 700 ? 700 : 2200))
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        d: 0.1 + Math.random() * 0.9,
        r: Math.random() < 0.03 ? 1.8 : 0.4 + Math.random() * 0.9,
        c: Math.random() < 0.2 ? '#FFD966' : Math.random() < 0.35 ? '#60A5FA' : '#E5E7EB',
        t: Math.random() * 6.28,
        fine: Math.random() < 0.35,
      }))
    }

    function frame(time: number) {
      const { zoom, pan } = v
      ctx.clearRect(0, 0, w, h)
      m.px += (m.x - m.px) * 0.05
      m.py += (m.y - m.py) * 0.05
      for (const s of stars) {
        if (s.fine && zoom < 1.15) continue
        const depth = s.d * zoom
        let x = (s.x + pan.x * depth + m.px * 30 * s.d) % w
        if (x < 0) x += w
        let y = (s.y + pan.y * depth + m.py * 30 * s.d) % h
        if (y < 0) y += h
        const dx = x - m.cx
        const dy = y - m.cy
        const dist = Math.hypot(dx, dy)
        if (dist < 90 && dist > 0) {
          const push = ((90 - dist) / 90) * 14
          x += (dx / dist) * push
          y += (dy / dist) * push
        }
        const tw = reduced ? 1 : 0.6 + 0.4 * Math.sin(time / 900 + s.t)
        ctx.globalAlpha = (0.25 + s.d * 0.75) * tw
        ctx.fillStyle = s.c
        ctx.beginPath()
        ctx.arc(x, y, s.r * (0.8 + zoom * 0.35), 0, 6.28)
        ctx.fill()
        if (s.r > 1.5) {
          ctx.globalAlpha *= 0.18
          ctx.beginPath()
          ctx.arc(x, y, s.r * 4, 0, 6.28)
          ctx.fill()
        }
        if (!reduced) {
          s.y -= 0.02 * s.d
          if (s.y < 0) s.y = h
        }
      }
      if (!reduced && Math.random() < 0.002 && meteors.length < 2) {
        meteors.push({ x: Math.random() * w, y: Math.random() * h * 0.4, l: 0 })
      }
      meteors = meteors.filter((mt) => mt.l < 40)
      for (const mt of meteors) {
        mt.x += 9
        mt.y += 4
        mt.l++
        const g = ctx.createLinearGradient(mt.x, mt.y, mt.x - 70, mt.y - 30)
        g.addColorStop(0, 'rgba(245,230,168,.8)')
        g.addColorStop(1, 'transparent')
        ctx.globalAlpha = 1 - mt.l / 40
        ctx.strokeStyle = g
        ctx.lineWidth = 1.4
        ctx.beginPath()
        ctx.moveTo(mt.x, mt.y)
        ctx.lineTo(mt.x - 70, mt.y - 30)
        ctx.stroke()
      }
      ctx.globalAlpha = 1
      if (nebulaRef.current) {
        nebulaRef.current.style.transform = `translate(${m.px * -18 + pan.x * 0.1}px,${m.py * -18 + pan.y * 0.1}px) scale(${0.85 + zoom * 0.15})`
      }
      if (moonRef.current) moonRef.current.style.translate = `${m.px * -40}px ${m.py * -40}px`
      if (glowRef.current && m.cx > -999) {
        m.gx += (m.cx - m.gx) * 0.12
        m.gy += (m.cy - m.gy) * 0.12
        glowRef.current.style.transform = `translate(${m.gx - 200}px,${m.gy - 200}px)`
      }
      raf = requestAnimationFrame(frame)
    }

    const onMove = (e: MouseEvent) => {
      m.x = e.clientX / w - 0.5
      m.y = e.clientY / h - 0.5
      if (m.cx === -999) {
        m.gx = e.clientX
        m.gy = e.clientY
        glowRef.current?.classList.add('on')
      }
      m.cx = e.clientX
      m.cy = e.clientY
      if (panning) {
        v.pan.x += e.clientX - last.x
        v.pan.y += e.clientY - last.y
        last = { x: e.clientX, y: e.clientY }
      }
    }
    const onLeave = () => {
      m.cx = m.cy = -999
      glowRef.current?.classList.remove('on')
    }
    const onDown = (e: MouseEvent) => {
      if (e.button !== 0 || (e.target as Element).closest(INTERACTIVE)) return
      panning = true
      last = { x: e.clientX, y: e.clientY }
      document.body.classList.add('panning')
    }
    const onUp = () => {
      panning = false
      document.body.classList.remove('panning')
    }
    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey) {
        e.preventDefault()
        v.zoom = Math.min(2.5, Math.max(0.6, v.zoom - e.deltaY * 0.002))
      }
    }

    resize()
    raf = requestAnimationFrame(frame)
    addEventListener('resize', resize)
    if (finePointer) {
      addEventListener('mousemove', onMove)
      document.documentElement.addEventListener('mouseleave', onLeave)
      addEventListener('mousedown', onDown)
      addEventListener('mouseup', onUp)
    }
    addEventListener('wheel', onWheel, { passive: false })
    return () => {
      cancelAnimationFrame(raf)
      removeEventListener('resize', resize)
      removeEventListener('mousemove', onMove)
      document.documentElement.removeEventListener('mouseleave', onLeave)
      removeEventListener('mousedown', onDown)
      removeEventListener('mouseup', onUp)
      removeEventListener('wheel', onWheel)
    }
  }, [])

  const setZoom = (z: number) => {
    view.current.zoom = Math.min(2.5, Math.max(0.6, z))
  }

  return (
    <>
      <div className="nebula" ref={nebulaRef} aria-hidden="true" />
      <div className="moon" ref={moonRef} aria-hidden="true" />
      <canvas id="space" ref={canvasRef} aria-hidden="true" />
      <div className="cursor-glow" ref={glowRef} aria-hidden="true" />
      <div className="zoom-ctl" role="group" aria-label="Universe zoom">
        <button type="button" onClick={() => setZoom(view.current.zoom + 0.25)} aria-label="Zoom in" title="Zoom into the stars">
          +
        </button>
        <button type="button" onClick={() => setZoom(view.current.zoom - 0.25)} aria-label="Zoom out" title="Zoom out">
          {'−'}
        </button>
        <button
          type="button"
          onClick={() => {
            view.current.zoom = 1
            view.current.pan = { x: 0, y: 0 }
          }}
          aria-label="Reset view"
          title="Reset view"
        >
          {'↺'}
        </button>
      </div>
    </>
  )
}
