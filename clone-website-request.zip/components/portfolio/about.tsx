import { aboutChips, aboutParagraphs, profile } from '@/lib/portfolio-data'
import { external } from './icons'

export function About() {
  return (
    <section id="about">
      <h2 className="title">About Me</h2>
      <div className="about-grid">
        <div className="card glass term">
          <p className="mono tag">about.md</p>
          {aboutParagraphs.map((p) => (
            <p key={p.slice(0, 20)}>{p}</p>
          ))}
          <div className="btns">
            <a className="btn primary" href={profile.resume} target="_blank" rel="noopener">
              View Resume
            </a>
            <a className="btn" href={profile.linkedin} {...external}>
              LinkedIn
            </a>
          </div>
        </div>
        <div className="about-side">
          <div className="orbit-list">
            {aboutChips.map(([title, sub]) => (
              <div className="chip glass" key={title}>
                <b>{title}</b>
                <small>{sub}</small>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
