'use client'

import { useEffect } from 'react'

const SELECTOR = '.card,.chip,.stop,.title'

export function RevealObserver() {
  useEffect(() => {
    const root = document.querySelector('main')
    if (!root || !('IntersectionObserver' in window)) return
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in')
            io.unobserve(e.target)
          }
        }),
      { threshold: 0.12 },
    )
    const track = (el: Element) => {
      el.classList.add('reveal')
      if (!el.classList.contains('in')) io.observe(el)
    }
    root.querySelectorAll(SELECTOR).forEach(track)
    const mo = new MutationObserver((records) =>
      records.forEach((r) =>
        r.addedNodes.forEach((n) => {
          if (n.nodeType !== 1) return
          const el = n as Element
          if (el.matches(SELECTOR)) track(el)
          el.querySelectorAll(SELECTOR).forEach(track)
        }),
      ),
    )
    mo.observe(root, { childList: true, subtree: true })

    const hash = decodeURIComponent(location.hash.slice(1))
    const target = hash ? document.getElementById(hash) : null
    if (target) requestAnimationFrame(() => target.scrollIntoView({ block: 'start' }))

    return () => {
      io.disconnect()
      mo.disconnect()
    }
  }, [])

  return null
}
