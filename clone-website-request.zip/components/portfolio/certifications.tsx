'use client'

import { useState } from 'react'
import { certs } from '@/lib/portfolio-data'

const tabs = [
  ['All', 'All'],
  ['Achievement', 'Achievements'],
  ['Certification', 'Certifications'],
] as const

export function Certifications() {
  const [filter, setFilter] = useState<string>('All')
  const visible = certs.filter((c) => filter === 'All' || c.type === filter)

  return (
    <section id="certifications">
      <h2 className="title">Certifications &amp; Achievements</h2>
      <div className="tabs" role="tablist" aria-label="Filter certifications and achievements">
        {tabs.map(([key, label]) => (
          <button
            key={key}
            type="button"
            role="tab"
            aria-selected={filter === key}
            className={`tab${filter === key ? ' on' : ''}`}
            onClick={() => setFilter(key)}
          >
            {label}
          </button>
        ))}
      </div>
      <div className="certs">
        {visible.map((c) => (
          <div key={c.title + c.detail} className={`card glass cert${c.type === 'Achievement' ? ' award' : ''}`}>
            <p className="mono tag">{c.type === 'Achievement' ? '★ Achievement' : '✓ Certification'}</p>
            <h3>{c.title}</h3>
            <p>{c.detail}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
