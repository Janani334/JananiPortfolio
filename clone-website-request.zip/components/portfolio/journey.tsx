'use client'

import { useState } from 'react'
import { journey } from '@/lib/portfolio-data'

export function Journey() {
  const [active, setActive] = useState(journey.length - 2)

  return (
    <section id="journey">
      <h2 className="title">My Journey</h2>
      <p className="sub mono">{'> pick a stop on the route'}</p>
      <div className="journey" role="tablist" aria-label="Journey milestones">
        {journey.map(([label], i) => (
          <button
            key={label}
            type="button"
            role="tab"
            aria-selected={active === i}
            className={`stop${active === i ? ' on' : ''}`}
            onClick={() => setActive(i)}
          >
            <i />
            <span>{label}</span>
          </button>
        ))}
      </div>
      <p className="desc mono card glass" aria-live="polite">
        {'> '}
        {journey[active][0]}: {journey[active][1]}
      </p>
    </section>
  )
}
