'use client'

import { useState } from 'react'
import { skillGroups } from '@/lib/portfolio-data'

export function Skills() {
  const [selected, setSelected] = useState<{ name: string; desc: string } | null>(null)

  return (
    <section id="skills">
      <h2 className="title">Skills &amp; Tech Universe</h2>
      <p className="sub mono">hover or tap a technology</p>
      <div className="skill-groups">
        {skillGroups.map((group) => (
          <div className="card glass" key={group.title}>
            <h3 className="mono">{group.title}</h3>
            <div className="nodes">
              {group.items.map(([name, desc]) => {
                const pick = () => setSelected({ name, desc })
                const on = selected?.name === name
                return (
                  <button
                    key={name}
                    type="button"
                    className={`node${on ? ' on' : ''}`}
                    onMouseEnter={pick}
                    onFocus={pick}
                    onClick={pick}
                    aria-pressed={on}
                  >
                    {name}
                  </button>
                )
              })}
            </div>
          </div>
        ))}
      </div>
      <p className="desc mono" aria-live="polite">
        {selected ? `> ${selected.name}: ${selected.desc}` : '> select a technology to see how I use it'}
      </p>
    </section>
  )
}
