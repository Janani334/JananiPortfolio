'use client'

/* eslint-disable @next/next/no-img-element */
import { useCallback, useEffect, useRef, useState } from 'react'
import { profile, projects, type Shot } from '@/lib/portfolio-data'
import { GithubIcon, external } from './icons'

type LightboxState = { id: number; shots: Shot[]; index: number; sync: (i: number) => void }

function Gallery({
  shots,
  title,
  onOpen,
}: {
  shots: Shot[]
  title: string
  onOpen: (shots: Shot[], index: number, sync: (i: number) => void) => void
}) {
  const [index, setIndex] = useState(0)
  const thumbsRef = useRef<HTMLDivElement>(null)
  const total = shots.length
  const go = (i: number) => setIndex((i + total) % total)
  const [src, caption] = shots[index]

  useEffect(() => {
    const strip = thumbsRef.current
    const el = strip?.children[index] as HTMLElement | undefined
    if (el && strip) {
      strip.scrollTo({ left: el.offsetLeft - strip.clientWidth / 2 + el.clientWidth / 2, behavior: 'smooth' })
    }
  }, [index])

  return (
    <div className="gallery">
      <div className="gal-stage">
        <button type="button" className="gal-main" onClick={() => onOpen(shots, index, setIndex)} aria-label={`Open ${caption} full screen`}>
          <img key={src} src={src || '/placeholder.svg'} alt={`${title}: ${caption}`} loading="lazy" decoding="async" />
          <span className="gal-zoom" aria-hidden="true">
            {'⤢ view'}
          </span>
        </button>
        {total > 1 && (
          <>
            <button type="button" className="gal-nav prev" onClick={() => go(index - 1)} aria-label="Previous screenshot">
              {'❮'}
            </button>
            <button type="button" className="gal-nav next" onClick={() => go(index + 1)} aria-label="Next screenshot">
              {'❯'}
            </button>
          </>
        )}
      </div>
      <p className="gal-cap mono small">
        {caption} ({index + 1}/{total})
      </p>
      {total > 1 && (
        <div className="thumbs" ref={thumbsRef}>
          {shots.map(([s, c], i) => (
            <button
              key={s}
              type="button"
              className={`thumb${i === index ? ' on' : ''}`}
              onClick={() => setIndex(i)}
              aria-label={`Show ${c}`}
              aria-pressed={i === index}
            >
              <img src={s || '/placeholder.svg'} alt="" loading="lazy" />
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function Lightbox({ state, onClose }: { state: LightboxState; onClose: () => void }) {
  const [index, setIndex] = useState(state.index)
  const closeRef = useRef<HTMLButtonElement>(null)
  const total = state.shots.length

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      if (e.key === 'ArrowLeft') setIndex((i) => (i - 1 + total) % total)
      if (e.key === 'ArrowRight') setIndex((i) => (i + 1) % total)
    }
    addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    closeRef.current?.focus()
    return () => {
      removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [total, onClose])

  useEffect(() => {
    state.sync(index)
  }, [index, state])

  const [src, caption] = state.shots[index]

  return (
    <div
      className="lightbox"
      role="dialog"
      aria-modal="true"
      aria-label={caption}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <button type="button" ref={closeRef} className="lb-close" onClick={onClose} aria-label="Close">
        {'×'}
      </button>
      {total > 1 && (
        <button type="button" className="gal-nav prev" onClick={() => setIndex((index - 1 + total) % total)} aria-label="Previous image">
          {'❮'}
        </button>
      )}
      <figure>
        <img key={src} src={src || '/placeholder.svg'} alt={caption} />
        <figcaption className="mono small">
          {caption} ({index + 1}/{total}) ·{' '}
          <a href={src} target="_blank" rel="noopener noreferrer">
            open original
          </a>
        </figcaption>
      </figure>
      {total > 1 && (
        <button type="button" className="gal-nav next" onClick={() => setIndex((index + 1) % total)} aria-label="Next image">
          {'❯'}
        </button>
      )}
    </div>
  )
}

function TiltCard({ className, children }: { className: string; children: React.ReactNode }) {
  const ref = useRef<HTMLElement>(null)
  const [canTilt, setCanTilt] = useState(false)

  useEffect(() => {
    setCanTilt(matchMedia('(hover: hover)').matches && !matchMedia('(prefers-reduced-motion: reduce)').matches)
  }, [])

  const onMove = (e: React.MouseEvent) => {
    const el = ref.current!
    const r = el.getBoundingClientRect()
    const x = (e.clientX - r.left) / r.width - 0.5
    const y = (e.clientY - r.top) / r.height - 0.5
    el.style.transform = `perspective(900px) rotateY(${x * 6}deg) rotateX(${-y * 6}deg) translateY(-4px)`
  }

  return (
    <article
      ref={ref}
      className={className}
      onMouseMove={canTilt ? onMove : undefined}
      onMouseLeave={canTilt ? () => (ref.current!.style.transform = '') : undefined}
    >
      {children}
    </article>
  )
}

const filters = ['All', 'Excel', 'SQL', 'Power BI'] as const

export function Projects() {
  const [filter, setFilter] = useState<(typeof filters)[number]>('All')
  const [lightbox, setLightbox] = useState<LightboxState | null>(null)
  const visible = projects.filter((p) => filter === 'All' || p.tool === filter)

  const open = useCallback(
    (shots: Shot[], index: number, sync: (i: number) => void) => setLightbox({ id: Date.now(), shots, index, sync }),
    [],
  )
  const close = useCallback(() => setLightbox(null), [])

  return (
    <section id="projects">
      <h2 className="title">Projects</h2>
      <p className="sub mono">{'> six data analytics projects, click a screenshot to enlarge'}</p>
      <div className="tabs" role="tablist" aria-label="Filter projects by tool">
        {filters.map((f) => (
          <button
            key={f}
            type="button"
            role="tab"
            aria-selected={filter === f}
            className={`tab${filter === f ? ' on' : ''}`}
            onClick={() => setFilter(f)}
          >
            {f}{' '}
            <span className="count">{f === 'All' ? projects.length : projects.filter((p) => p.tool === f).length}</span>
          </button>
        ))}
      </div>
      <div className="projects">
        {visible.map((p) => (
          <TiltCard key={p.id} className="card glass project">
            <Gallery shots={p.shots} title={p.title} onOpen={open} />
            <p className="mono tag">
              {p.tool}
              {p.tool === 'SQL' ? ' · includes ER diagram' : ' · final dashboard'}
            </p>
            <h3>{p.title}</h3>
            <p>{p.summary}</p>
            <ul className="feat">
              {p.features.map((f) => (
                <li key={f}>{f}</li>
              ))}
            </ul>
            <div className="tags">
              {p.tags.map((t) => (
                <span key={t}>{t}</span>
              ))}
            </div>
            <div className="btns">
              <a className="btn primary" href={p.github} {...external}>
                <GithubIcon /> GitHub
              </a>
              <a className="btn" href={p.readme} {...external}>
                Case Study
              </a>
            </div>
          </TiltCard>
        ))}
      </div>
      <p className="center">
        <a className="btn ghost" href={profile.repo} {...external}>
          <GithubIcon /> Browse the full analytics repository
        </a>
      </p>
      {lightbox && <Lightbox key={lightbox.id} state={lightbox} onClose={close} />}
    </section>
  )
}
