import { About } from '@/components/portfolio/about'
import { Certifications } from '@/components/portfolio/certifications'
import { Contact } from '@/components/portfolio/contact'
import { Education } from '@/components/portfolio/education'
import { Hero } from '@/components/portfolio/hero'
import { Journey } from '@/components/portfolio/journey'
import { Projects } from '@/components/portfolio/projects'
import { RevealObserver } from '@/components/portfolio/reveal-observer'
import { SiteFooter } from '@/components/portfolio/site-footer'
import { SiteNav } from '@/components/portfolio/site-nav'
import { Skills } from '@/components/portfolio/skills'
import { SpaceBackground } from '@/components/portfolio/space-background'

export default function Page() {
  return (
    <>
      <a className="skip" href="#about">
        Skip to content
      </a>
      <SpaceBackground />
      <SiteNav />
      <main>
        <Hero />
        <About />
        <Skills />
        <Projects />
        <Education />
        <Certifications />
        <Journey />
        <Contact />
      </main>
      <SiteFooter />
      <RevealObserver />
    </>
  )
}
